<?php
    require_once ('../models/model_registroEmpleado.php');

    $nif=$_POST['dni'];
    $nombre=$_POST['first-name'];
    $apellido=$_POST['last-name'];
    $email=$_POST['email'];

    if (validaEntrada($nif,$nombre,$apellido,$email)){

        alta_empleado($nif,$nombre,$apellido,$email);

        echo "Se ha dado de alta correctamente";

    }else{

        echo "Error: No se permiten campos vacios";
    }
  

    require_once("../views/view_registroEmpleado.php");
