<?php
    require_once('../views/view_loginApostante.php');
    require_once ('../models/model_dameApostante.php');
    session_start();

    $dni=$_POST['user'];
    $apellido=$_POST['password'];
    $resultado = dameApostante($dni,$apellido);
    if ($resultado['dni'] == $dni && $resultado['apellido'] == $apellido){

        $_SESSION['dni']=$resultado['dni'];
        $_SESSION['nombre']=$resultado['nombre'];
        $_SESSION['apellido']=$resultado['apellido'];
        $_SESSION['saldo']=$resultado['saldo'];
        $_SESSION['logueado']=true;

        header("location: ../views/view_inicioApostante.php");

    }else{

        echo ("Usuario o contrasenia incorrecto");
    }


    

    //include_once("../views/view_loginEmpleado.php");

?>