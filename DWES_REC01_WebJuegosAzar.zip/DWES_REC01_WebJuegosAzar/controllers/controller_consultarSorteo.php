<?php
    require ('../models/model_dameSorteos.php');
    require ('../models/model_dameSorteo.php');
    session_start();
    $sorteos = dame_sorteos();
    
    if (isset($_POST['nsorteo'])) {
        $nsorteo = $_POST['nsorteo'];
        $infosorteo = dame_sorteo($nsorteo);
    }

    require_once('../views/view_consultarSorteo.php');

?>



