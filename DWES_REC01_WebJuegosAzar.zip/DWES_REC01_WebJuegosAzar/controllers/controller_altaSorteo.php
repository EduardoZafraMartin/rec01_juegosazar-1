<?php

require_once ('../models/model_altaSorteo.php');
    //session_start();

    $fecha=$_POST['fecha'];
    $dni=$_SESSION['dni'];
    if (validarInput($fecha)){

        aniadirSorteo($fecha,$dni);
        echo("Sorteo aniadido");

    }else{

        echo ("La fecha no es correcta");
    }

?>