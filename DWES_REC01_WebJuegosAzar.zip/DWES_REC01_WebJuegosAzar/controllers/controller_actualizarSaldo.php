<?php
session_start();
require_once ('../models/model_validarActualizarSaldo.php');
require_once ('../models/model_actualizarSaldo.php');


if (isset($_POST['recarga'])) {
    //Recogemos la recarga, la validamos
    if(validarActualizarSaldo($_POST['recarga'])){  
    //Actualizar saldo
    actualizarSaldo($_POST['recarga'],$_SESSION['dni'],$_SESSION['saldo']);
    //actualizar variables de sesion
    $_SESSION['saldo']=($_SESSION['saldo']+$_POST['recarga']);
    }else{
        echo ("Valores introducidos incorrectos");
    }

}else{
    echo ("Valores introducidos incorrectos");
}

require_once ('../views/view_actualizarSaldo.php');

?>