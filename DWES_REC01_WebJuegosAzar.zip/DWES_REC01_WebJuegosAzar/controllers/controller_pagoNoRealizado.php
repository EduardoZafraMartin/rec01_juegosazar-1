<?php
  
   session_start();
   include '../models/apiRedsys.php';
   require_once ('../models/model_validarActualizarSaldo.php');
   require_once ('../models/model_actualizarSaldo.php');
   require_once ('../models/model_dameClaveComercio.php');
   
   
   if (isset($_SESSION['pagoPendiente'])) {
      
       unset ($_SESSION['pagoPendiente']);
       header("location: ../views/view_actualizarSaldo.php");
       echo ("No se ha cargado el saldo "); 
    }
