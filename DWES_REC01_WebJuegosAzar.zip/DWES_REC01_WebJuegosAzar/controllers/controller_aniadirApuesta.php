<?php
    require ('../models/model_dameSorteosActivos.php');
    require ('../models/model_aniadirApuesta.php');
    require ('../models/model_actualizarRecaudacionSorteo.php');
    require ('../models/model_dameSorteo.php');

    session_start();
    $sorteos = dame_sorteos_activos();
    if (isset($_POST['nsorteo']) && isset($_POST['n1']) 
        && isset($_POST['n2'])  && isset($_POST['n3']) && isset($_POST['n4'])
        && isset($_POST['n5']) && isset($_POST['n6'])  && isset($_POST['c'])
        && isset($_POST['r'])) {
             
        aniadirApuesta($_POST['nsorteo'],$_SESSION['dni'],$_POST['n1'],$_POST['n2'],
                        $_POST['n3'],$_POST['n4'],$_POST['n5'],$_POST['n6'],$_POST['c'],
                        $_POST['r']);
        
        $sorteo = dame_sorteo($_POST['nsorteo']);
        actualizarRecaudacionSorteo($_POST['nsorteo'],$sorteo['recaudacion']);  
        echo("Apuesta realizada correctamente");
        
    }else{
        echo ("Los campos son erroneos");
    }


    require_once('../views/view_realizarApuesta.php');

?>