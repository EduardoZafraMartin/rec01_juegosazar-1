<?php
    require ('../models/model_dameApuestas.php');
    session_start();
    $apuestas = dameApuestas($_SESSION['dni']);
    
    if (isset($_POST['napuesta'])) {
        $napuesta = $_POST['napuesta'];
        $infoapuestas = consulta2($napuesta);
    }

    require_once('../views/view_consultarApuesta.php');

?>
