<?php
    require ('../models/model_dameSorteos.php');
    require ('../models/model_dameSorteo.php');
    require ('../models/model_dameApuestas.php');
    require ('../models/model_dameApuesta.php');
    session_start();
    
    $apuestas = dameApuestas($_SESSION['dni']);
    
    if (isset($_POST['nsorteo'])) {
        $nsorteo = $_POST['nsorteo'];
        $infoapuestas = dameApuesta($nsorteo);
        
    }

    

    require_once('../views/view_consultarApuesta.php');
