<?php
    require ('../models/model_realizarSorteo.php');
    require ('../models/model_dameSorteosActivos.php');
    session_start();
    $sorteos = dame_sorteos_activos();
    if (isset($_POST['sorteoSeleccionado']) && !empty ($_POST['sorteoSeleccionado'])) {
        $nsorteo = $_POST['sorteoSeleccionado'];
        realizarSorteo($nsorteo);
        echo ("Sorteo  realizado correctamente");
    }   
   require_once('../views/view_realizarSorteo.php');
