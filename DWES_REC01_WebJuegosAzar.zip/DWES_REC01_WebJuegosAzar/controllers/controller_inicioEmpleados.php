<?php
    
    include_once("../views/view_inicioEmpleados.php");
?>