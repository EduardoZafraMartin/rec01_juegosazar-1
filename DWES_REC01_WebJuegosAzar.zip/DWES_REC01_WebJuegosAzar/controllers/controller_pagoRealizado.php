<?php
  
   session_start();
   include '../models/apiRedsys.php';
   require_once ('../models/model_validarActualizarSaldo.php');
   require_once ('../models/model_actualizarSaldo.php');
   require_once ('../models/model_dameClaveComercio.php');
   
   
   if (isset($_SESSION['pagoPendiente'])) {
      
       //Actualizar saldo
       actualizarSaldo($_SESSION['pagoPendiente'],$_SESSION['dni'],$_SESSION['saldo']);
       //actualizar variables de sesion
       $_SESSION['saldo']=($_SESSION['saldo']+$_SESSION['pagoPendiente']);
       unset ($_SESSION['pagoPendiente']);
       header("location: ../views/view_inicioApostante.php");
    }
