<?php
    require_once('../views/view_loginEmpleado.php');
    require_once ('../models/model_loginEmpleado.php');
    session_start();

    $dni=$_POST['user'];
    $apellido=$_POST['password'];
    $resultado = dameUsuario($dni,$apellido);
    if ($resultado['dni'] == $dni && $resultado['apellido'] == $apellido){
        $_SESSION['dni']=$resultado['dni'];
        $_SESSION['nombre']=$resultado['nombre'];
        $_SESSION['apellido']=$resultado['apellido'];
        $_SESSION['logueado']=true;
        header("location: ../views/view_inicioEmpleados.php");

    }else{
        echo ("Usuario o contraseña incorrecto");
        
    }

    //require_once('../views/view_inicioEmpleados.php');
    

    //include_once("../views/view_loginEmpleado.php");

?>