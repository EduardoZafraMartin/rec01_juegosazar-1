<?php	
	//PETICION AUTORIZACION INSITE
	{
	  "DS_MERCHANT_AMOUNT": "145",
	  "DS_MERCHANT_CURRENCY": "978",
	  "DS_MERCHANT_MERCHANTCODE": "999008881",
	  "DS_MERCHANT_ORDER": "1446068581",
	  "DS_MERCHANT_IDOPER": "9c75f357629acb672e0f5444401d138f02e834ad ",
	  "DS_MERCHANT_TERMINAL": "1",
	  "DS_MERCHANT_TRANSACTIONTYPE": "0"
	}
	//RESPUESTA AUTORIZACION
	{
	  "Ds_Amount": "145",
	  "Ds_AuthorisationCode": "501602",
	  "Ds_CardNumber": "454881********04",
	  "Ds_Card_Brand": "1",
	  "Ds_Card_Country": "724",
	  "Ds_Currency": "978",
	  "Ds_Language": "1",
	  "Ds_MerchantCode": "999008881",
	  "Ds_Order": "1446068581",
	  "Ds_Response": "0000",
	  "Ds_SecurePayment": "0",
	  "Ds_Terminal": "1",
	  "Ds_TransactionType": "0"
	}
?>