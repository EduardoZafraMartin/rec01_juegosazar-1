<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
<head>
    <style type="text/css">
        div {
    background-color: #d8da3d;
    width: 350px;
	text-align: center
}
  </style>
    <body>
    <div>
        <p>Bienvenido/a <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
        </div>
        <p><h2>Menu Apostante</h2></p>
        <ul>
        <li><a href="../controllers/controller_aniadirApuesta.php">Realizar apuesta</a></li>
        <li><a href="view_actualizarSaldo.php">Cargar saldo</a></li>
        <li><a href="../controllers/controller_consultarApuesta.php">Consultar Apuesta</a></li>
        <li><a href="view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>