<html>
    <body>
        <!---->
        <?php
            /*if (isset($_POST['alta'])){
                $nif=$_POST['dni'];
                $nombre=$_POST['first-name'];
                $apellido=$_POST['last-name'];
                $email=$_POST['email'];
                
            }*/
        ?>
        <!---->
        <p>
            Registro empleados
        </p>
        <form action="../controllers/controller_registroEmpleado.php" method="POST">
            <input type="text" name="dni">DNI</input><br><br>
            <input type="text" name="first-name">Nombre</input><br><br>
            <input type="text" name="last-name">Apellido</input><br><br>
            <input type="text" name="email">Email</input><br><br>
            <input type="submit" name="alta" value="registrar"><br><br>
            <a href="../views/view_loginEmpleado.php">Login empleado</a>
        </form>
    </body>
</html> 