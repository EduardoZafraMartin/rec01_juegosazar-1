<?php
require_once ("../controllers/controller_actualizarSaldo.php");
if(!isset ($_SESSION ['logueado']) || $_SESSION ['logueado'] ==false){
    header("location: view_loginApostante.php");
}
?>
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p><br>
    <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
    <p>Menu Apostante</p><br>
    <form action="../controllers/controller_actualizarSaldo.php" method="POST">
        <input type="number" name="recarga">
        <input type="submit" name="aniadirSaldo" value="Aniadir Saldo">
    </form>


        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>