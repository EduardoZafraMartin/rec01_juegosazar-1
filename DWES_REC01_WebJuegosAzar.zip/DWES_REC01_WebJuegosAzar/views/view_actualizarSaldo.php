<?php

    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <head>
    <style type="text/css">
        div {
    background-color: #d8da3d;
    width: 350px;
	text-align: center
}
  </style>
    </head>

    <body>
        <div>
        <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
        </div>
    
    <p><h2>Cargar Saldo</h2></p><br>
    <form action="../controllers/controller_actualizarSaldo.php" method="POST">
        <input type="number" name="recarga">
        <input type="submit" name="aniadirSaldo" value="Aniadir Saldo">
    </form>
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>