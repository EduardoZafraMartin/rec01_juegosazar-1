<?php

require('../controllers/controller_realizarSorteo.php');
/*if(!isset ($_SESSION ['logueado']) || $_SESSION ['logueado'] ==false){
    header("location: view_loginEmpleado.php");
}*/

?>
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p><br>
    <form  method="POST">
        <label for="form">Elige el sorteo </label>
            <select name="sorteoSeleccionado" required>
                <?php foreach ($sorteos as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] . '</option>'; ?>
                <?php endforeach; ?>
            </select><br>
        <input type="submit" name="Realizar sorteo" value="Realizar sorteo">
    </form>

        <ul>
        <li><a href="../views/view_inicioEmpleados.php">Volver a menu</a></li>
        </ul>
        
    </body>
</html>