<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['logueado']) || ($_SESSION['logueado'] == false)) {
    header("location: view_loginEmpleado.php");
}
?>
<html>

<body>

    <head>
        <style type="text/css">
            div {
                background-color: #d8da3d;
                width: 243px;
                height: 30px;
                text-align: center
            }
        </style>
    </head>

    <form method="POST" action="../controllers/controller_realizarSorteo.php">
        <div>
            <p>Bienvenido <?php echo $_SESSION['nombre']; ?> <?php echo $_SESSION['apellido']; ?></p><br>
        </div>
        <p>
        <h2>Realizar Sorteo</h2>
        </p>

        <label for="form">Elige el sorteo </label>
        <select name="sorteoSeleccionado" style="text-align:center;color: red;background: #f0f0f0;" required>
            <?php foreach ($sorteos as $sort) : ?>
                <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] . '</option>'; ?>
            <?php endforeach; ?>
        </select><br><br>
        <input type="submit" name="Realizar sorteo" value="Realizar sorteo">
    </form>

    <ul>
        <li><a href="../views/view_inicioEmpleados.php">Volver a menu</a></li>
    </ul>

</body>

</html>