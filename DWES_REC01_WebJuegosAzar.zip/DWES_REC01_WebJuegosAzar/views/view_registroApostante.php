<html>
<body>
    <p>
        <h1>Registro apostantes</h1>
    </p>
    <form action="../controllers/controller_registroApostante.php" method="POST">
        <input type="text" name="dni">DNI</input><br><br>
        <input type="text" name="first-name">Nombre</input><br><br>
        <input type="text" name="last-name">Apellido</input><br><br>
        <input type="text" name="email">Email</input><br><br>
        <input type="submit" name="alta" value="registrar"><br><br>
        <a href="../views/view_loginApostante.php">Login Apostante</a>
    </form>
</body>
</html>