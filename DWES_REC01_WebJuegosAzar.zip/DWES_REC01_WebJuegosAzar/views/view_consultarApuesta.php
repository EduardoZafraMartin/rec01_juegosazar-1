<html>
    <head>
        <style>
            table, td, th {
            border: 1px solid black;
            }
            table {
            border-collapse: collapse;
            width: 50%;
            }
        </style>
    </head>
    <body>
  
    <form action="../controllers/controller_consultarApuesta.php" method="POST">
        <label for="form">Elige apuesta </label>
            <select name="napuesta" required>
            <?php foreach ($apuestas as $apuesta) : ?>
                    <?php echo '<option value="' . $apuesta['napuesta'] . '"> Apuesta numero ' . $apuesta['napuesta'] . '</option>'; ?>
                <?php endforeach; ?>
                
            </select><br>
        <input type="submit" name="consultar" value="Consultar">
    </form>

    <?php 
        if (isset($_POST['consultar'])){
            ?>
            <table>
                <tr><td>Numero apuesta</td><td>Dni</td><td>Numero Sorteo</td><td>Fecha</td><td>Num1</td><td>Num2</td><td>Num3</td><td>Num4</td><td>Num5</td><td>Num6</td><td>Complementario</td><td>Importe Premio</td><td>Categoria Premio</td><td>Reintegro</td></tr>
                <?php echo '<tr><td>' . $infoapuestas['napuesta'] . '</td><td>' . $infoapuestas['dni'] . '</td><td>' . $infoapuestas['nsorteo'] . '</td><td>' . $infoapuestas['fecha'] . '</td><td>'
                 . $infoapuestas['n1'] . '</td><td>' . $infoapuestas['n2'] . '</td><td>' . $infoapuestas['n3'] . '</td><td>' . $infoapuestas['n4'] .
                  '</td><td>' . $infoapuestas['n5'] . '</td><td>' . $infoapuestas['n6'] . '</td><td>' . $infoapuestas['c'] .'</td><td>' . $infoapuestas['r'] .
                   '</td><td>' . $infoapuestas['importe_premio'] . '</td><td>' . $infoapuestas['categoria_premio'] . '</td><td>' . '</td></tr>'; ?>
            </table>
            <?php
        }
    ?>
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        </ul>
        
    </body>
</html>