<?php

    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <head>
        <style>
            table, td, th {
            border: 1px solid black;
            background-color:aquamarine
            }
            table {
            border-collapse: collapse;
            width: 50%;
            }
            div {
            background-color: #d8da3d;
            width: 350px;
            text-align: center
            }

        </style>
    </head>
    <body>
    <div>
        <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
        </div>

        <p><h2>Consultar Apuestas</h2></p><br>
  
    <form action="../controllers/controller_consultarApuesta.php" method="POST">
        <label for="form">Elige el sorteo </label>
            <select name="nsorteo" style="text-align:center;color: red;background: #f0f0f0;" required>
                <?php foreach ($apuestas as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero '
                     . $sort['nsorteo'] . '</option>'; ?>
                <?php endforeach; ?>
            </select><br><br>
        <input type="submit" name="consultar" value="Consultar">
    </form>

    <?php 
        if (isset($_POST['consultar'])){
            ?>
            <table>
                <tr><td>Numero apuesta</td><td>Dni</td><td>Numero Sorteo</td><td>Fecha</td><td>Num1</td><td>Num2</td><td>Num3</td><td>Num4</td><td>Num5</td><td>Num6</td><td>
                    Complementario</td><td>Reintegro</td><td>Importe Premio</td><td>Categoria Premio</td></tr>
                    <?php foreach ($infoapuestas as $apues) : ?>
                    <?php echo '<tr><td>' . $apues['napuesta'] . '</td><td>' . $apues['dni'] . '</td><td>' . $apues['nsorteo'] . '</td><td>' . $apues['fecha'] . '</td><td>'
                    . $apues['n1'] . '</td><td>' . $apues['n2'] . '</td><td>' . $apues['n3'] . '</td><td>' . $apues['n4'] .
                    '</td><td>' . $apues['n5'] . '</td><td>' . $apues['n6'] . '</td><td>' . $apues['c'] .'</td><td>' . $apues['r'] .
                    '</td><td>' . $apues['importe_premio'] . '</td><td>' . $apues['categoria_premio'] . '</td><td>' . '</td></tr>'; ?>
                    <?php endforeach; ?>
            </table>
            <?php
        }
    ?>
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        </ul>
        
    </body>
</html>