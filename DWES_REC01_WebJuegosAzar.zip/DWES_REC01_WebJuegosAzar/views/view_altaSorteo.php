
<?php

    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <head>
        <style type="text/css">
            div {
        background-color: #d8da3d;
        width: 200px;
        text-align: center
        }
        </style>
    </head>

    <body>
       
        <p>
            <h2>Alta Sorteo</h2>
        </p>
        <form action="../controllers/controller_altaSorteo.php" method="POST">
            Fecha Sorteo
            <input type="date" name="fecha"/><br><br>
            
            <input type="submit" name="alta" value="Dar de alta"><br><br>
            <a href="../views/view_inicioEmpleados.php">Volver a menu</a>
        </form>
    </body>
</html>