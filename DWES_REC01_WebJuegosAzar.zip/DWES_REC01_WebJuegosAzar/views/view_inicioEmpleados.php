<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <head>
        <style type="text/css">
            div {
        background-color: #d8da3d;
        width: 200px;
        text-align: center
        }
    </style>
    </head>

    <body>
        <div>
            <p>Bienvenido/a <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        </div>
   
        <p><h2>Menu Empleados</h2></p>
        <ul>
        <li><a href="view_altaSorteo.php">Alta de Sorteos</a></li>
        <li><a href="../controllers/controller_realizarSorteo.php">Realizar Sorteos</a></li>
        <li><a href="../controllers/controller_consultarSorteo.php">Consultar Sorteo</a></li>
        <li><a href="view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>