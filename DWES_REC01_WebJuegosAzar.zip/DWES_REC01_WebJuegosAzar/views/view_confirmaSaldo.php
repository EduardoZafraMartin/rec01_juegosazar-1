<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
    <body>
    <head>
        <style type="text/css">
            div {
        background-color: #d8da3d;
        width: 350px;
        text-align:center;
        }
  </style>
    </head>
    <div>
        <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
    </div>
    
   
    <form name="from" action="https://sis-t.redsys.es:25443/sis/realizarPago" method="POST">
        <input type="hidden" name="Ds_SignatureVersion" value="HMAC_SHA256_V1"/>
        <input type="hidden" name="Ds_MerchantParameters" value="<?php echo $_SESSION['merchantParametersEncriptados'] ?>"/>
        <input type="hidden" name="Ds_Signature" value="<?php echo $_SESSION['claveComercio'] ?>"/>
        <p>Estas seguro de que deseas aniadir <?php echo $_SESSION['pagoPendiente'];?> euros?</p>
        <input type="submit" name="aniadirSaldo" value="Confirmar Saldo">	
    </form>         
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>