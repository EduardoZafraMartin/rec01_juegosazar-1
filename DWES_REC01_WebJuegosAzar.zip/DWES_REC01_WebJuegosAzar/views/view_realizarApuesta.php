<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_loginEmpleado.php");
    }
?>
<html>
<head>
    <style type="text/css">
        div {
    background-color: #d8da3d;
    width: 350px;
	text-align:center;
}
  </style>
    </head>
    <body>
        <div><p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
             <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
        </div>
    
    <p><h2>Realizar apuesta</h2></p><br>
    <form name = "combinacion" action="../controllers/controller_aniadirApuesta.php" method="POST">

            <label for="form">Primer numero</label>
            <select name="n1" onchange = "quitaNumero1()"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-
                <?php for($i=1;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select>

            <label for="form">Segundo numero</label>
            <select name="n2" onchange = "quitaNumero2()"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-
            </select>

            <label for="form">Tercer numero</label>
            <select name="n3"onchange = "quitaNumero3()"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-
            </select>

            <label for="form">Cuarto numero</label>
            <select name="n4"onchange = "quitaNumero4()"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-      
            </select>

            <label for="form">Quinto numero</label>
            <select name="n5"onchange = "quitaNumero5()"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-       
            </select>

            <label for="form">Sexto numero</label>
            <select name="n6"; style="text-align:center;color: red;background: #f0f0f0;" required>
            <option value="0" selected>-      
            </select>

            <label for="form">Complementario</label>
            <select name="c"; style="text-align:center;color: red;background: #f0f0f0;" required>
                <?php for($i=1;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select>

            <label for="form">Reintegro</label>
            <select name="r"; style="text-align:center;color: red;background: #f0f0f0;" required>
                <?php for($i=0;$i<=9;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br><br>

        <label for="form">Elige el sorteo </label>
            <select name="nsorteo" required>
                <?php foreach ($sorteos as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] .
                     ' con fecha ' . $sort['fecha'] . '</option>'; ?>
                 <?php endforeach; ?>
                 
            </select><br><br>
        <input type="submit" name="realizarApuesta" value="Realizar Apuesta">
    </form>
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>


        <script>
        var numeros = ["-",1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32
                        ,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49];
        function quitaNumero1(){
            var numero;
            numero = parseInt(document.combinacion.n1[document.combinacion.n1.selectedIndex].value);
            var index = numeros.indexOf(numero);
            console.log (numero);
            if (numero > 0) {
                numeros.splice (index, 1);
                longitud = numeros.length;
                document.combinacion.n2.length = longitud;
                for(i=0; i<longitud; i++) { 
                    document.combinacion.n2.options[i].value = numeros[i];
                    document.combinacion.n2.options[i].text = numeros[i];
                }
            }else{ 
                document.combinacion.n2.length = 1;
                document.combinacion.n2.options[0].value = "-";
                document.combinacion.n2.options[0].text = "-";
            } 
            document.combinacion.n2.options[0].selected = true;
        }

        function quitaNumero2(){
            var numero;
            numero = parseInt(document.combinacion.n2[document.combinacion.n2.selectedIndex].value);
            var index = numeros.indexOf(numero);
            if (numero > 0) {
                numeros.splice (index, 1);
                longitud = numeros.length;
                document.combinacion.n3.length = longitud;
                for(i=0; i<longitud; i++) { 
                    document.combinacion.n3.options[i].value = numeros[i];
                    document.combinacion.n3.options[i].text = numeros[i];
                }
            }else{ 
                document.combinacion.n3.length = 1;
                document.combinacion.n3.options[0].value = "-";
                document.combinacion.n3.options[0].text = "-";
            } 
            document.combinacion.n3.options[0].selected = true;
        }

        function quitaNumero3(){
            var numero;
            numero = parseInt(document.combinacion.n3[document.combinacion.n3.selectedIndex].value);
            var index = numeros.indexOf(numero);
            if (numero > 0) {
                numeros.splice (index, 1);
                longitud = numeros.length;
                document.combinacion.n4.length = longitud;
                for(i=0; i<longitud; i++) { 
                    document.combinacion.n4.options[i].value = numeros[i];
                    document.combinacion.n4.options[i].text = numeros[i];
                }
            }else{ 
                document.combinacion.n4.length = 1;
                document.combinacion.n4.options[0].value = "-";
                document.combinacion.n4.options[0].text = "-";
            } 
            document.combinacion.n4.options[0].selected = true;
        }

        function quitaNumero4(){
            var numero;
            numero = parseInt(document.combinacion.n4[document.combinacion.n4.selectedIndex].value);
            var index = numeros.indexOf(numero);
            if (numero > 0) {
                numeros.splice (index, 1);
                longitud = numeros.length;
                document.combinacion.n5.length = longitud;
                for(i=0; i<longitud; i++) { 
                    document.combinacion.n5.options[i].value = numeros[i];
                    document.combinacion.n5.options[i].text = numeros[i];
                }
            }else{ 
                document.combinacion.n5.length = 1;
                document.combinacion.n5.options[0].value = "-";
                document.combinacion.n5.options[0].text = "-";
            } 
            document.combinacion.n5.options[0].selected = true;
        }

        function quitaNumero5(){
            var numero;
            numero = parseInt(document.combinacion.n5[document.combinacion.n5.selectedIndex].value);
            var index = numeros.indexOf(numero);
            if (numero > 0) {
                numeros.splice (index, 1);
                longitud = numeros.length;
                document.combinacion.n6.length = longitud;
                for(i=0; i<longitud; i++) { 
                    document.combinacion.n6.options[i].value = numeros[i];
                    document.combinacion.n6.options[i].text = numeros[i];
                }
            }else{ 
                document.combinacion.n6.length = 1;
                document.combinacion.n6.options[0].value = "-";
                document.combinacion.n6.options[0].text = "-";
            } 
            document.combinacion.n6.options[0].selected = true;
        }

        </script>
    </body>
</html>