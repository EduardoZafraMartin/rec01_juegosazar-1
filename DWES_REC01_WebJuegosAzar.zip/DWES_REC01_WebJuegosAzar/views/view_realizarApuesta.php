<?php
require_once('../controllers/controller_aniadirApuesta.php');

/*session_start();
if(!isset ($_SESSION ['logueado']) || $_SESSION ['logueado'] ==false){
    header("location: view_loginApostante.php");*/

?>
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p><br>
    <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
    <p>Menu Apostante</p><br>
    <form action="../controllers/controller_aniadirApuesta.php" method="POST">


            <label for="form">Primer numero</label>
            <select name="n1" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Segundo numero</label>
            <select name="n2" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Tercer numero</label>
            <select name="n3" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Cuarto numero</label>
            <select name="n4" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Quinto numero</label>
            <select name="n5" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Sexto numero</label>
            <select name="n6" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Complementario</label>
            <select name="c" required>
                <?php for($i=0;$i<50;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

            <label for="form">Reintegro</label>
            <select name="r" required>
                <?php for($i=0;$i<=9;$i++){
                        echo '<option value= '.$i.'>'.$i.'</option>';
                } ?>         
            </select><br>

        <label for="form">Elige el sorteo </label>
            <select name="nsorteo" required>
                <?php foreach ($sorteos as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] .
                     ' con fecha ' . $sort['fecha'] . '</option>'; ?>
                 <?php endforeach; ?>
                 
            </select><br>
        <input type="submit" name="realizarApuesta" value="Realizar Apuesta">
    </form>
        <ul>
        <li><a href="../views/view_inicioApostante.php">Volver a menu</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>