<?php
    require_once("../db/db.php");

    function dameApostante($dni,$apellido)  {
        global $conexion;
        try {

            $sql=("SELECT dni,apellido,nombre,saldo from apostante where dni ='$dni' and apellido ='$apellido'");
            $statement = $conexion->prepare($sql);
            $statement->bindParam(":dni", $dni);
            $statement->bindParam(":apellido", $apellido);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
            
        }   catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

    }
?>