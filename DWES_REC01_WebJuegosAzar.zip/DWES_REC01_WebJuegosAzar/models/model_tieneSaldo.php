<?php

require_once("../db/db.php");


   
    function tieneSaldo($napuestas,$dni){
        global $conexion;
        try {
        //TODO:CAMBIAR
        $sql=("SELECT saldo from apostante where dni='$dni'");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado=$statement->fetch(PDO::FETCH_ASSOC);
        if($resultado['saldo']>=$napuestas){

            return true;

        }else{
            return false;
        }
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

        

    }
