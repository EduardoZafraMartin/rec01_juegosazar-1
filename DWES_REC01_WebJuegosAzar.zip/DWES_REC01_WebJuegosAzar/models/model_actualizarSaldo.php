<?php

require_once("../db/db.php");

   
    function actualizarSaldo($recarga,$dni,$saldo){
        global $conexion;
        try {
        $sql=("UPDATE apostante SET saldo = ($recarga + $saldo) WHERE dni='$dni'");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }
