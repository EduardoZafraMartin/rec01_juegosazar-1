<?php

require_once("../db/db.php");


    function dameApuestas($dni) {
        global $conexion;
        try {
            $sql=("SELECT napuesta,fecha, nsorteo from apuestas where dni='$dni' GROUP BY nsorteo");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }


?>