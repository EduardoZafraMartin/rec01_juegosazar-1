<?php

require_once("../db/db.php");


    function dameApuestas($dni) {
        global $conexion;
        try {
            $sql=("SELECT napuesta,fecha, nsorteo from apuestas where dni='$dni'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }
/*
    function consulta2($napuesta,$nsorteo){
        global $conexion;
        try {
            $sql2=("SELECT napuesta,dni,nsorteo,fecha,n1,n2,n3,n4,n5,n6,c,r,importe_premio,categoria_premio from apuestas where napuesta='$napuesta' AND nsorteo='$nsorteo'");
            $statement = $conexion->prepare($sql2);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }*/


?>