<?php

require_once("../db/db.php");

   
    function dameSaldo($dni){
        global $conexion;
        try {

        $sql=("SELECT saldo from apostante where dni='$dni'");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado=$statement->fetch(PDO::FETCH_ASSOC);
        return $resultado['saldo'];
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }
