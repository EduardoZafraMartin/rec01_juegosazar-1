<?php

require_once("../db/db.php");

   
    function tieneSaldo($napuestas,$dni){
        global $conexion;
        try {

        $sql=("SELECT saldo from apostante where dni='$dni'");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado=$statement->fetch(PDO::FETCH_ASSOC);
        return $resultado;
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

        if($resultado['saldo']>=$napuestas){

            return true;

        }else{
            return false;
        }

    }
