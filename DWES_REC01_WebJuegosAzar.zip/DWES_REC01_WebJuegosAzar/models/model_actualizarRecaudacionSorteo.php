<?php

require_once("../db/db.php");

   
    function actualizarRecaudacionSorteo($nsorteo,$recaudacion){
        global $conexion;
        try {
        $sql2=("UPDATE sorteo SET recaudacion = ($recaudacion + 1) WHERE nsorteo='$nsorteo'");
        $statement = $conexion->prepare($sql2);
        $statement->execute();
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

    }

?>