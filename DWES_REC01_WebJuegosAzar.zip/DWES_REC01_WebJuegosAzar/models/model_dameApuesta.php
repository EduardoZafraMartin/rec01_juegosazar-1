<?php

require_once("../db/db.php");

    function dameApuesta($nsorteo){
        global $conexion;
        try {
            $sql=("SELECT napuesta,dni,nsorteo,fecha,dni,n1,n2,n3,n4,n5,n6,c,r,importe_premio,categoria_premio from apuestas where nsorteo='$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }


?>