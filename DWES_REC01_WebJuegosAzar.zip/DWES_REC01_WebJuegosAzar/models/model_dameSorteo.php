<?php

require_once("../db/db.php");

    function dame_sorteo($nsorteo){
        global $conexion;
        try {
            $sql2=("SELECT nsorteo,fecha,recaudacion,recaudacion_premios,dni,activo,combinacion_ganadora from sorteo where nsorteo='$nsorteo'");
            $statement = $conexion->prepare($sql2);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }
//TODO: VER QUE HACER CON ESTO
    /*function dameApuestas() {
        global $conexion;
        try {
            $sql=("SELECT napuesta from apuestas");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }

    function consulta2($napuesta,$nsorteo){
        global $conexion;
        try {
            $sql2=("SELECT napuesta,dni,nsorteo,fecha,n1,n2,n3,n4,n5,n6,c,r,importe_premio,categoria_premio from apuestas where napuesta='$napuesta' AND nsorteo='$nsorteo'");
            $statement = $conexion->prepare($sql2);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }
*/

?>