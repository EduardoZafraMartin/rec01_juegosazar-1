<?php
   
    function validarActualizarSaldo($recarga){
       
        if($recarga>0){

            return true;

        }else{
            return false;
        }

    }
?>