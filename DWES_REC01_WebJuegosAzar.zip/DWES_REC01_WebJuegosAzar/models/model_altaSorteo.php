<?php
    require_once ('../models/model_altaSorteo.php');
    require_once("../db/db.php");

    function validarInput($fecha){

        return true;

    }

    function aniadirSorteo($fecha,$dni){

        global $conexion;

        try {
            $numeroSorteo = generarNumero();
            $timestamp = date('Y-m-d H:i:s', strtotime($fecha));  
            $sql = "INSERT into sorteo (nsorteo,fecha,recaudacion,recaudacion_premios,dni,activo,combinacion_ganadora) 
            values ('$numeroSorteo','$timestamp',0,0,'$dni','1','0')";
            $aniadirSorteo = $conexion->prepare($sql);
            $aniadirSorteo->execute();
            //return $obtenerID->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }



    }

    function generarNumero(){

        global $conexion;

        try {
           
            $sql = " SELECT MAX( NSORTEO ) AS MAXNSORTEO FROM sorteo";
            $dameUltimoNumero = $conexion->prepare($sql);
            $dameUltimoNumero->execute();
            $resultado=$dameUltimoNumero->fetch(PDO::FETCH_ASSOC);
            //var_dump($resultado);
            //$ultimoCodigoSrting=(substr($resultado['MAXNSORTEO'],1));
            if(isset ($resultado) ){
                $ultimoCodigo = (float) substr($resultado['MAXNSORTEO'],1);        
                if($ultimoCodigo<9){
                    //echo 'S00'.($ultimoCodigo +1);
                    return 'S00'.($ultimoCodigo +1);

                }elseif($ultimoCodigo>99){
    
                    return 'S'.($ultimoCodigo +1);

                }else{
                    
                    return 'S0'.($ultimoCodigo +1);
                }

            }else{
                return 'S001';
            }
            

            
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    include_once("../views/view_altaSorteo.php");

?>