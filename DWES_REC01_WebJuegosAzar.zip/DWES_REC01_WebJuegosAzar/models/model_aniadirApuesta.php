<?php

require_once("../db/db.php");

   
    function aniadirApuesta($nsorteo,$dni,$n1,$n2,$n3,$n4,$n5,$n6,$c,$r){
        global $conexion;
        try {
    
        $sql=("INSERT INTO apuestas(DNI , NSORTEO, FECHA, N1, N2, N3, N4, N5, N6, C, R)
         VALUES ('$dni','$nsorteo',NOW(),'$n1','$n2','$n3','$n4','$n5','$n6','$c','$r')");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        
        
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

    }

?>