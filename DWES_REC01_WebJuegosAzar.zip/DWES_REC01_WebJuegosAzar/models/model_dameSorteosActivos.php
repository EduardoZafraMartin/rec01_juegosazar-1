<?php

require_once("../db/db.php");

    function dame_sorteos_activos() {
        global $conexion;
        try {
            $sql=("SELECT nsorteo,fecha from sorteo WHERE activo=1");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }



?>