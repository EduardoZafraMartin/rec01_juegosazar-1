<?php

require_once("../db/db.php");
require_once("model_dameSaldo.php");


    function realizarSorteo($nsorteo){

        $combinacion=array(1,2,3,4,5,6,7,8);
        /*array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion,dameNumeroRandom($combinacion));
        array_push($combinacion, rand(0,9));]*/
        
        //Actualizamos sorteo con combinacion ganadora y recaudacion de premios

        $combinacionGanadora=  $combinacion[0] . " " . $combinacion[1] . " " .  $combinacion[2]. " " . 
        $combinacion[3]. " " .  $combinacion[4] . " " .  $combinacion[5] . " " .  $combinacion[6] .
         " " .  $combinacion[7];
        $recaudacionApuestas= dameRecaudacionApuestas($nsorteo);
        //var_dump($recaudacionApuestas);
        $apostastantesGananReintegro= dameApostastantesGananReintegro($nsorteo,$combinacion[7]);
        //var_dump($apostastantesGananReintegro);
        $recaudacionPremios = ($recaudacionApuestas*0.5) + count($apostastantesGananReintegro);
        var_dump($recaudacionPremios);
        actualizarSorteo($nsorteo,$recaudacionPremios,$combinacionGanadora);  
        
        //Recuperamos lista de apuestas del sorteo
        $listaApuestas=dameApuestasDelSorteo($nsorteo);

        //Reparte premios para el reintegro(1 euro)
        repartirBeneficios($apostastantesGananReintegro,1,null);

       //Reparte premios para los que han acertado 6 digitos
        $recaudacionPremio6= ($recaudacionApuestas*0.5)*0.5;
        repartePremio($listaApuestas,$recaudacionPremio6,$combinacion,6,'6');
        //Reparte premios para los que han acertadi 5 digitos
        $recaudacionPremio5= ($recaudacionApuestas*0.5)*0.15;
        repartePremio($listaApuestas,$recaudacionPremio5,$combinacion,5,"5");
        //Reparte premios para los que han acertadi 4 digitos
        $recaudacionPremio4= ($recaudacionApuestas*0.5)*0.1;
        repartePremio($listaApuestas,$recaudacionPremio4,$combinacion,4,"4");
        //Reparte premios para los que han acertadi 3 digitos
        $recaudacionPremio3= ($recaudacionApuestas*0.5)*0.05;
        repartePremio($listaApuestas,$recaudacionPremio3,$combinacion,3,"3");  
        //Reparte premios para los que han acertadi 5 digitos y complementario
        $recaudacionPremio5C= ($recaudacionApuestas*0.5)*0.2;
        repartePremio5C($nsorteo,$recaudacionPremio5C,$combinacion);

       
    }

    //Metodos privados----------------------------------------------------------------------------------

    function dameApuestasDelSorteo($nsorteo){

        global $conexion;

        try {
            $sql=("SELECT dni,n1,n2,n3,n4,n5,n6,napuesta 
            from apuestas 
            where nsorteo ='$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            return $statement->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }

    }

    function repartePremio($listaApuestas,$recaudacionPremio,$combinacion,$numeroAciertos,$categoriaPremio){
        $listaGanadores=array();
                for ($i=0;$i < count($listaApuestas);$i++){
                $cont=0;
                    for ($j=1;$j<7;$j++){
                        $apuesta=$listaApuestas[$i];
                        $numero = (int) $apuesta['n'.$j];
                        if(in_array($numero,$combinacion)){
                            $cont++;
                        }
                    }   
                if($cont == $numeroAciertos){

                    array_push($listaGanadores,$listaApuestas[$i]);
                    unset($listaApuestas[$i]);
                }
            }

            //var_dump($listaGanadores);
            if(!empty($listaGanadores)){

                $premio=$recaudacionPremio / count($listaGanadores);
                //echo ("Premio" . $premio);
                repartirBeneficios($listaGanadores,$premio,$categoriaPremio);
            }
            
        
    }

    //Recuperamos lista de apuestas filtradas por el numero de sorteo que corresponda y el complementario
    //Reparte premios para aquellos que de la lista recuperada coincidan con 5 de los numeros de la combinacion ganadora
    function repartePremio5C($nsorteo,$recaudacionPremio5C,$combinacion){

        global $conexion;

        try {
           // $complementario=$combinacion[6];
            //var_dump($complementario);
            $sql=("SELECT dni,n1,n2,n3,n4,n5,n6,napuesta from apuestas where nsorteo ='$nsorteo' AND c = $combinacion[6]");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $listaPosibleGanadores=$statement->fetchAll(PDO::FETCH_ASSOC);
            repartePremio($listaPosibleGanadores,$recaudacionPremio5C,$combinacion,5,"5C");
           
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }
    }

    function dameApostastantesGananReintegro($nsorteo,$reintegro){

        
        global $conexion;

        try {
            $sql=("SELECT dni,napuesta from apuestas where r='$reintegro' AND nsorteo ='$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }

    }

    function repartirBeneficios($apuestasGanadoras,$premio,$categoriaPremio){

        global $conexion;

        try {
            foreach ($apuestasGanadoras as $apuesta) {
                //Actualizar saldo
                $dni=$apuesta['dni'];
                $saldoActualValor=dameSaldo($dni);
                $sql=("UPDATE apostante SET saldo = ($saldoActualValor + $premio) WHERE dni='$dni'");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                //Recuperar importe premio actual
                $napuesta=$apuesta['napuesta'];
                $sql=("SELECT importe_premio from apuestas where napuesta='$napuesta'");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                $resultado=$statement->fetch(PDO::FETCH_ASSOC);
                $sumatorioPremio = $resultado['importe_premio'] + $premio;


                //Actualizar el premio y la categoria de la apuesta

                $sql=("UPDATE apuestas SET importe_premio = '$sumatorioPremio',categoria_premio = '$categoriaPremio' WHERE napuesta='$napuesta'");
                $statement = $conexion->prepare($sql);
                $statement->execute();
            }

        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }
    }

    function dameRecaudacionApuestas($nsorteo){

        global $conexion;

        try {
            $sql=("SELECT recaudacion FROM sorteo WHERE  nsorteo = '$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado['recaudacion'];
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }

    }

    function actualizarSorteo($nsorteo,$recaudacionPremios,$combinacionGanadora){

        global $conexion;


        try {
            var_dump($recaudacionPremios);
            $sql=("UPDATE sorteo SET recaudacion_premios = '$recaudacionPremios' , activo = 0, combinacion_ganadora ='$combinacionGanadora' WHERE nsorteo = '$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
 
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }
    }

     function dameNumeroRandom($combinacion){

        $numero=0;

         do {

            $numero= rand(1,49);

        } while (in_array($numero,$combinacion));
        
       return $numero;

    }
?>