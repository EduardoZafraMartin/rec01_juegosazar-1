<?php


//require_once("../db/db.php");

   
    function dameClaveComercio(){
    
     //La clave de comercio deberia estar guardada en base de datos, en este caso es una de prueba
    
     return "sq7HjrUOBfKmC576ILgskD5srU870gJ7";
        
        
    }
