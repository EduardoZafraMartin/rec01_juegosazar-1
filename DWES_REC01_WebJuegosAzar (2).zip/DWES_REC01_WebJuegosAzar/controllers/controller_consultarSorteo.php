<?php
    require ('../models/model_consultarApuesta.php');
    session_start();
    $sorteos = dame_sorteos();
    
    if (isset($_POST['nsorteo'])) {
        $nsorteo = $_POST['nsorteo'];
        $infosorteo = consulta($nsorteo);
    }

    require_once('../views/view_consultarSorteo.php');

?>