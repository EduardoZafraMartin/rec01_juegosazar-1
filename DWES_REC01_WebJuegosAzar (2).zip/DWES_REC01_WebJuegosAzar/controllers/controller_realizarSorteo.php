<?php
    require ('../models/model_realizarSorteo.php');
    session_start();
    $sorteos = dameSorteosActivo();
    if (isset($_POST['sorteoSeleccionado'])) {
        $nsorteo = $_POST['sorteoSeleccionado'];
        realizarSorteo($nsorteo);
        echo ("Sorteo  realizado correctamente");
    }





   
   require_once('../views/view_realizarSorteo.php');

?>