<?php
    require_once ('../models/model_realizarApuesta.php');
    session_start();

    $sorteos = dame_sorteos();
    //var_dump($departamentos);
    require_once('../views/view_realizarApuesta.php');





    $nsorteo=$_POST['nsorteo'];
    $napuestas=$_POST['napuestas'];
    $dni=$_SESSION['dni'];

    $resultado = tieneSaldo($napuestas,$dni);
    if ($resultado['dni'] == $dni && $resultado['apellido'] == $apellido){

        $_SESSION['dni']=$resultado['dni'];
        $_SESSION['nombre']=$resultado['nombre'];
        $_SESSION['apellido']=$resultado['apellido'];
        $_SESSION['saldo']=$resultado['saldo'];

        header("location: ../views/view_inicioApostante.php");

    }else{

        echo ("Usuario o contrasenia incorrecto");
    } 


    

    //include_once("../views/view_loginEmpleado.php");

?>