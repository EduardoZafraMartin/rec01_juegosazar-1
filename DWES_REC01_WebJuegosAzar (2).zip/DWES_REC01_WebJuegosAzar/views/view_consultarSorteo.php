<html>
    <head>
        <style>
            table, td, th {
            border: 1px solid black;
            }
            table {
            border-collapse: collapse;
            width: 50%;
            }
        </style>
    </head>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p><br>
    <form action="../controllers/controller_consultarSorteo.php" method="POST">
        <label for="form">Elige el sorteo </label>
            <select name="nsorteo" required>
                <?php foreach ($sorteos as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] . '</option>'; ?>
                <?php endforeach; ?>
            </select><br>
        <input type="submit" name="consultar" value="Consultar">
    </form>

    <?php 
        if (isset($_POST['consultar'])){
            ?>
            <table>
                <tr><td>Numero sorteo</td><td>Fecha</td><td>recaudacion</td><td>recaudacion_premios</td><td>DNI</td><td>Activo</td><td>combinacion_gandora</td></tr>
                <?php echo '<tr><td>' . $infosorteo['nsorteo'] . '</td><td>' . $infosorteo['fecha'] . '</td><td>' . $infosorteo['recaudacion'] . '</td><td>' . $infosorteo['recaudacion_premios'] . '</td><td>' . $infosorteo['dni'] . '</td><td>' . $infosorteo['activo'] . '</td><td>' . $infosorteo['combinacion_ganadora'] . '</td></tr>'; ?>
            </table>
            <?php
        }
    ?>
        
        <ul>
        <li><a href="../views/view_inicioEmpleados.php">Volver a menu</a></li>
        </ul>
        
    </body>
</html>