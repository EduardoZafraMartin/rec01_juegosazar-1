
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p><br>
    <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
    <p>Menu Apostante</p><br>
    <form action="../controllers/controller_realizarApuesta.php" method="POST">
        <label for="form">Elige el sorteo </label>
            <select name="nsorteo" required>
                <?php foreach ($sorteos as $sort) : ?>
                    <?php echo '<option value="' . $sort['nsorteo'] . '"> Sorteo numero ' . $sort['nsorteo'] . ' con fecha ' . $sort['fecha'] . '</option>'; ?>
                 <?php endforeach; ?>
            </select><br>
            <label for="form">Numero de apuestas </label>
            <select name="napuestas" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select><br>
        
        <input type="submit" name="apostar" value="Realizar apuesta">
    </form>
        
        <ul>
        <li><a href="../views/view_cargarSaldo.php">Cargar saldo</a></li>
        <li><a href="../views/view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>