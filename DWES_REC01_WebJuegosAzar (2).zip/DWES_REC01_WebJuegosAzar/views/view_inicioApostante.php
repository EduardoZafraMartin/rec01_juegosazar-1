<?php
//require("../db/db.php");
require('../controllers/controller_apostante.php');

?>
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
    <p>Con DNI: <?php echo $_SESSION['dni'];?> y saldo: <?php  echo $_SESSION['saldo'];?></p>
        <p><h2>Menu Apostante</h2></p>
        <ul>
        <li><a href="../controllers/controller_realizarApuesta.php">Realizar apuesta</a></li>
        <li><a href="view_cargarSaldo.php">Cargar saldo</a></li>
        <li><a href="view_consultarApuesta.php">Consultar Apuesta</a></li>
        <li><a href="view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>