<?php
   session_start();
   
   //Si cerramos sesión, volvemos a la vista del login para poder loguearnos de nuevo.
   if(session_destroy()) {
      header("Location: view_loginEmpleado.php");
   }
?>