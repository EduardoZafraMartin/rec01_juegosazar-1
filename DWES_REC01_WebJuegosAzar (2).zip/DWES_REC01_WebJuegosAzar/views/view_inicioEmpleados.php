<?php
//require("../db/db.php");
require('../controllers/controller_empleados.php');

?>
<html>
    <body>
    <p>Bienvenido <?php echo $_SESSION['nombre'];?>  <?php  echo $_SESSION['apellido'];?></p>
        <p><h2>Menu Empleados</h2></p><br>
        <ul>
        <li><a href="view_altaSorteo.php">Alta de Sorteos</a></li>
        <li><a href="view_realizarSorteo.php">Realizar Sorteos</a></li>
        <li><a href="../controllers/controller_consultarSorteo.php">Consultar Sorteo</a></li>
        <li><a href="view_logout.php">Cerrar Sesion</a></li>
        </ul>
    </body>
</html>