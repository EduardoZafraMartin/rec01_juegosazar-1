<?php

require_once("../db/db.php");

    function alta_apostante($nif,$nombre,$apellido,$email) {
        global $conexion;

        try {
            $obtenerID = $conexion->prepare("INSERT into apostante (dni,nombre,apellido,email,saldo) values ('$nif','$nombre','$apellido','$email',0)");
            $obtenerID->execute();
            //return $obtenerID->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    function validaEntrada($nif,$nombre,$apellido,$email){

        //Validamos si algún campo del registro está vacio
        //$valido = true;
        if(empty($nif)||empty ($nombre) ||empty ($apellido)||empty( $email)) {
            
          echo "Hay campos vacios";
          return false;
        }


        //Validamos si el DNI está escrito correctamente ( 8 numeros y 1 letra)

        $nums=['1','2','3','4','5','6','7','8','9','0'];

        $numeros=substr($_POST['dni'],0,8);
        $letra=substr($_POST['dni'],8,1);

        for ($i=0; $i < strlen($numeros); $i++) {
            if(array_search($numeros[$i],$nums)===false){

                echo "Error: El DNI es incorrecto";
                return false;
                
            }else{
                return true;
            }
            if (strlen($numeros)!=8||strlen($letra)!=1){

                echo "Error: El DNI es incorrecto";
                return false;
                
            }else{
                return true;
            }
                
        }

        //Validamos el email

       if(false !== strpos($email, "@") && false !== strpos($email, ".")){
            
            echo "Error: El email es incorrecto";
           return false;
        }else{
            return true;
        }
         
        
        
    }