<?php

require_once("../db/db.php");

    function dame_sorteos() {
        global $conexion;
        try {

            $sql=("SELECT nsorteo,fecha from sorteo where activo = 1");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
            
        }   catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }

    function tieneSaldo($napuestas,$dni){
        global $conexion;
        try {

        $sql=("SELECT saldo from apostante where dni='$dni'");
        $statement = $conexion->prepare($sql);
        $statement->execute();
        $resultado=$statement->fetch(PDO::FETCH_ASSOC);
        return $resultado;
        }catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

        if($resultado['saldo']>=$napuestas){

            return true;

        }else{
            return false;
        }

    }
