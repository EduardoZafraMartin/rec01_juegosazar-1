<?php

require_once("../db/db.php");

    function dameSorteosActivo() {
        global $conexion;
        try {
            $sql=("SELECT nsorteo,fecha from sorteo WHERE activo=1");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }
    }

    function realizarSorteo($nsorteo){

        global $conexion;

       $numero1 = rand(0,50); 
       $numero2 = rand(0,50);  
       $numero3 = rand(0,50);  
       $numero4 = rand(0,50);  
       $numero5 = rand(0,50);  
       $numero6 = rand(0,50);   
       $reintegro = rand(0,9); 

       $recaudacionApuestas= dameRecaudacionApuestas($nsorteo);
        
       $recaudacionPremios = $recaudacionApuestas*0.5;


       actualizarSorteo($nsorteo,$recaudacionPremios);
    
        repartePremioReintegro($reintegro);

    /*    
    //Las personas que se han acertado el reintegro se llevan 1 euro    
    select dni from apuestas where c=4;
    //Actualizar recaudacion premios, quitando la suma de las personas que hemos obtenido de la anterior query
    //50% DE LA RECAUDACION SE LO LLEVAN LOS SIGUIENTES(categoria 6)
    select dni from apuestas where n1 = 1 and n2 = 2 and n3=3 and n4=4 and n5=5 and n6=6;
    //20% DE LA RECAUDACION SE LO LLEVAN LOS SIGUIENTES (categoria 5c)
    select dni from apuestas where n1 = 1 and n2 = 2 and n3=3 and n4=4 and n5=5 and c=6;
    //15% DE LA RECAUDACION SE LO LLEVAN LOS SIGUIENTES (categoria 4)
    select dni from apuestas where n1 = 1 and n2 = 2 and n3=3 and n4=4 ;
    //10% DE LA RECAUDACION SE LO LLEVAN LOS SIGUIENTES (categoria 3)
    select dni from apuestas where n1 = 1 and n2 = 2 and n3=3 ;
*/


    }

    function repartePremioReintegro($reintegro){

        global $conexion;

        try {
            $sql=("SELECT dni from apuestas where c='$reintegro'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
            $resultado[0]['dni'];

            foreach ($resultado as $fila) {
                $dni=$fila['dni'];
                $sql=("SELECT saldo from apostante where dni='$dni'");
                $statement = $conexion->prepare($sql);
            $statement->execute();
            $saldoActual=$statement->fetch(PDO::FETCH_ASSOC);
            $saldoActualValor=$saldoActual['saldo'];


            $sql=("UPDATE apostante SET saldo = ($saldoActualValor+1) WHERE dni='$dni'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
 
            }

        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }
    }


       

    function dameRecaudacionApuestas($nsorteo){

        global $conexion;

        try {
            $sql=("SELECT recaudacion FROM sorteo WHERE  nsorteo = '$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado['recaudacion'];
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }

    }

    function actualizarSorteo($nsorteo,$recaudacionPremios){

        global $conexion;


        try {
            $sql=("UPDATE sorteo SET recaudacion_premios = '$recaudacionPremios' , activo = 0 WHERE nsorteo = '$nsorteo'");
            $statement = $conexion->prepare($sql);
            $statement->execute();
 
        } catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        
        }

     }

     



?>